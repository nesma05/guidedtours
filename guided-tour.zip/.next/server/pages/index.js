"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 690:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/Navbar.tsx
var Navbar = __webpack_require__(951);
// EXTERNAL MODULE: ./components/Hero.tsx
var Hero = __webpack_require__(547);
;// CONCATENATED MODULE: ./utils/constants.ts
const tours = [
    {
        id: "group-tour",
        title: "Group Walking Tours \u2013 Tangier",
        description: "The tour focuses on the historical, cultural, and architectural heritage of Tangier.",
        type: "Walking Tour",
        time: "4 HOURS",
        badge: "MOST POPULAR",
        image: "/img/group-tour.jpg"
    },
    {
        id: "private-tour",
        title: "Private Walking Tours \u2013 Tangier",
        description: "Customisable tours to suit your taste. Our private tours allow your group to have an educated guide all to yourselves.",
        type: "Driving & Walking Tour",
        time: "5 HOURS",
        badge: "",
        image: "/img/private-tour.jpg"
    }, 
];
const myStory = [
    {
        id: "text1",
        text: `My name is Mo Ben and I started Guided Tours of Tangier with one
    clear vision, to provide an intimate walking tour of Tangier’s old
    town that would enthuse my guests with its amazing history, its
    famous characters and its magnificently varied architecture. I
    want to offer something new and fresh.`
    },
    {
        id: "text2",
        text: `Simply put, I want my guests to fall in love with Tangier!`,
        style: "yes"
    },
    {
        id: "text3",
        text: `I was born and raised in Tangier. After graduating from university
    I spent 25 years guiding tours all over Morocco. I am of
    Moroccan-Arab-Berber heritage, so I am never at a loss for words
    and loving having a laugh and a good time.`
    },
    {
        id: "text4",
        text: `After 25 years of living in hotels, I decided it was time to come
    home to my beautiful city. I often ask myself how I could ever
    have left such an incredible place . I am passionate about guiding
    and proud of the reputation I have gained as a tourist guide.`
    },
    {
        id: "text5",
        text: `When you book a tour with me , you will be opening the door to
    experience the true essence of the place we will visit together.
    My tours are informative, may be irreverent, will be full of
    memorable moments, and are above all fun. I am a Moroccan Tourist
    Guide Association Member, regarded to be the gold standard
    qualification for guiding in Morocco.`
    }, 
];
const walkingTour = [
    {
        id: "text1",
        text: `Start your holiday with us and let us give you inside knowledge on what to 
    see, where to go , and things to do.`
    },
    {
        id: "text2",
        text: `The walks focus on the historical, cultural, and architectural heritage of 
    Tangier. Most of the major historical sites of interest are covered, including the 
    world-famous Kasbah in  the Old Town.`
    },
    {
        id: "text3",
        text: `On  our Group Walking Tours, we have an absolute maximum of 10 walkers to
    ensure you have a first-class experience. We feel strongly that tours of 30, 40 or
    50 more, just cannot give you the same experience and enjoyment.
    `
    },
    {
        id: "text4",
        text: `Alternatevily, our Private Tours allow you to see even more landmarks and 
    sights around Tangier both in the Old and New towns and can even be altered to suit 
    your personal tastes/interests, as you will be the only walkers on the tour.`
    }, 
];
const toursDets = [
    {
        id: "group-tour",
        description: `The walking tour focuses on the historical , cultural and architectural
  heritage of Tangier`,
        infoList: [
            {
                name: "Duration",
                value: "3 Hours"
            },
            {
                name: "Schedule",
                value: "from 9 am onward daily"
            },
            {
                name: "Departure Point",
                value: "Sea Port"
            }, 
        ],
        tourList1: [],
        text: [
            `Many of the historical sites of interest in Tangier are covered, including 
  world- famous Kasbah. You also visit inside The Old Medina. This intimate Tangier 
  walking tour ties together history, culture , and provides  insider information from
  our local specialist.`, 
        ],
        title1: `Our Tangier Tour`,
        tourList2: [
            "Our public tours always have a maximum of 10 guests per tour to ensure an engaging experience for all.",
            "The starting point for our tours is outside the central entrance of the seaport",
            "unless agreed otherwise with the customer. More details will be in the booking confirmation email.",
            "Please bring your booking confirmation with you.",
            "The tour is not wheelchair accessible as there are some steps.", 
        ],
        title2: `More About Your Group Walking Tour`,
        paragraphs: [
            `Tangier with its national geographical locations enjoys the best of both land 
      and sea. While being located on the coastal area which is the meeting point of 
      the two seas(The Mediterranean Sea and The Atlantic Ocean), It is also within 
      easy access of the Rif Mountain Range and it is this very geographical location 
      which provides the city and its surrounding  areas with such an abundance of 
      produce.
  `,
            `Come on a tour with us to discover the innumerable secrets buried within the 
  kasbah and dark closes of Tangier's Old Town surrounding the Medina. Built on 
  centuries of struggle and shaped by the most extraordinary-and daring-of peoples, 
  the historic sites and old landmarks that punctuate Tangier's magnificent skyline 
  and the Medina are brought to life on this Old Town Walking Tour. Unexpected 
  curiosities and hidden places of peace abound in these amazingly well-preserved 
  streets of stark contrasts.
  `,
            `Your tour will explore Old Tangier,  a tour designed for the more discerning
  wanderer. Taking you from the medieaval times to the 20th century, when Tangier 
  enjoyed a 44 years  international zone status and then onward.
  `,
            `After pick up  from the seaport or your hotel we take a short walk along the 
  newly designed promenade with its Marina to enjoy spectacular views of the bay 
  and the beach of Tangier  and then  towards the Medina, considered one of the most 
  spectacular Medinas of north Africa. 
  `,
            `Your guide one of Tangier Guided Tours can illustrate how The 
  Kasbah(Citadel, watch tower) became very trendy in the sixsties and seventies 
  attracting hippies, bohemians and the likes of The Rolling Stones, 
  Jim Morrison and Bob Dylan. The Woolworth heiress Barbara Hutton who once 
  lived in the heart of the Kasbah is synonymous with this fascinating part of Tangier.
  `,
            `Learn about the real life of Tangier's  souks to witness Morocco’s famous spices and
   its incredible fresh produce passing vendors selling olives, vegetables and 
   colourful fruits. We shall see the Berber ladies who come from the mountain areas
   to sell their home made goats cheese , leben sour milk and organic BIO vegetables 
   in the daily souk. We shall learn about the importance of bread in Moroccan meals 
   as we visit a traditional bakery as well as the sweet pasteries and mint tea.`,
            `Find out what life was really like in the Medieval Old Town when you walk around 
      the Jewish neigbourhood, Medina and the Petit Socco with its Cafes ,Shops and 
      more, which inspired the Beat Generation , Jack Kerouak , William Boroughs, 
      Brion Ginson etc...`,
            `The main square of the city(The Grand Socco), famed for inspiring Henri Matisse 
      is a must and fitting final point before returning towards the seaport where you 
      board your ferry back to Spain or back to your hotel.`,
            `Step back in time, in the company of writers, philosophers, body-snatchers and 
      let your guide*make history come alive!`,
            `There will be no more than 10 of you on the tour to ensure your full engagement 
      and involvement.`,
            `Book your tour today. You will not regret it.`, 
        ],
        titles3: "",
        paragraphs2: [],
        pricesDetails: {
            image: "/img/group-tour-details.jpg",
            prices: [
                {
                    category: "Adult",
                    price: "$30"
                },
                {
                    category: "Youth (Ages 12-16)",
                    price: "$30"
                },
                {
                    category: "Child (Ages 11 and Under)",
                    price: "Free"
                }
            ]
        }
    },
    {
        id: "private-tour",
        description: "Our Private Tangier Tours allow your group to have an experienced and educated guide all to yourselves.",
        infoList: [],
        tourList1: [
            `The normal starting point for our tours is outside the central entrance of the seaport, but we can meet the guests at their city-center hotel if requested
    `,
            `Can be up to 10 people per group`,
            `Please bring your booking confirmation with you
    `,
            `The tour is not wheelchair accessible as there are some steps`, 
        ],
        text: "We can even customise the tour to suit your tastes. You see even more landmarks and sights around Tangier. The private Tour is at your pace, including when to stop for refreshments. We can also arrange for our guide to pick you up from any Tangier city center hotel.",
        title1: "Details for our Private Tangier Tour",
        tourList2: [
            "The starting point for our tours is outside the central entrance of the seaport , unless agreed otherwise with the customer. More details will be in the booking confirmation email.",
            "Can be up to 10 people per group (If more than 10, contact us first for a quote).",
            "Please bring your booking confirmation with you.",
            "The tour is not wheelchair accessible as there are some steps.", 
        ],
        title2: "City of Tangier",
        paragraphs: [
            "The history of Tangier is inextricably linked to its strategic geographical location  on the Strait of Gibraltar as it enjoys the best of both land and sea. While being located on the coastal area which is the meeting point of the two seas(The Mediterranean Sea and The AtlanticOcean) ; it is also within easy access of the Rif Mountain Range and it is this very geographical location which provides the city and its surrounding areas with such an abundance pf produce.",
            "Strategically located, Tangier has always been a cultural nexus for European, Arab, and African civilazations.",
            "Tangier , however, remained under international administration until 1956, when it was returned to the now-independent kingdom of Morocco. Its time as an international zone was very much the city`s heyday\xa0; during this time its image as a romantic and sensuously exotic place was reflected in literature and on the big screen. Come on a tour with us to discover the innumerable secrets buried within the Kasbah and dark closes of Tangier`s Old Town and Medina.",
            "Built on centuries of struggle and shaped by the most extraordinary- and daring- of peoples, the historic sites and old landmarks that punctuate Tangier`s magnificent skyline and Kasbah are brought to life on this Private Tour. Unexpected curiosities and hidden places of peace abound in these amazingly well- preserved streets of stark contrasts.", 
        ],
        title3: "Our Private Tangier Tour",
        paragraphs2: [
            "Your Guide, one of Tangier Guided Tours`, will explore the highly prestigeous residential area of jebel Kabir (the Old Mountain) passing palaces belonging to kings and royalty, then you continue to Cape Spartel, where the seas (Atlantic and Mediterranean) mingle and then on to the mythical caves of Hercules where you can witness the glory of the Greek mythology. When you head down the mountain you will enjoy fantastic views as the city spreads out before you in all its glory before reaching the Medina\xa0. Once there the clocks turn back on time as you walk deep into  medieaval  Tangier  with its old labyrinthic and often chaotic streets and blind alleyways\xa0; yet thriving with incredible street life. It is a tour designed for the more discerning wanderer, taking you from the 17th century , to the colonial time , and then onward. See and visit the Medina ,the Grand Socco  Square where you will mingle with the local people, see the Berber markets , souks and marvel at the array of spices, olives, vegetables and colourful fruits.",
            "In your Private tour you will also  visit  the 17thc legendary Kasbah(Watch Tower)  with its ramparts and battlements dating back to the 16th century\xa0; where you can recall the good old days when celebrities such as The Rolling Stones, Jim Morisson and Bob Dylan among many more enjoyed their heydays and probably listen to(Rock The Kasbah) by the Clash.",
            "Find out what life was really like in the Medieval Old Town when you walk around the Jewish neigbourhood with its synagoges, Medina, and The Petit Socco with its cafes, shops and more which inspired the beat generation of  Jack Kerouak, Brion Ginson, Truman Capote etc...",
            "Do not be fooled by the name, construction only started at the end of the 19th century\xa0! Also, on the full day Private Tour you will see The Royal Palace, The Lord Mayors House and much more of the new town and its remarkable architecture.",
            "Finally, the tour ends back at the seaport or back to your city \u2013center hotel after the exploration of the Kasbah, Medina, Souks and Bazars.", 
        ],
        pricesDetails: {
            image: "/img/private-tour-details.jpg",
            prices: [
                {
                    category: "Half Day (3.5 Hours)",
                    price: "$195"
                },
                {
                    category: "Full Day (7 Hours)",
                    price: "$345"
                }
            ]
        }
    }, 
];

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/card.tsx



const card = ({ tour  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "card flex basis-1/2 flex-col overflow-hidden rounded-t-xl shadow-lg transition-all duration-200 hover:shadow-xl",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative w-full cursor-pointer",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/${tour.id}`,
                        passHref: true,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "card-overlay absolute z-20 h-full w-full bg-black/30 transition duration-300",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "absolute bottom-6 left-6 flex flex-col gap-3 sm:flex-row md:flex-col lg:flex-row",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center rounded-sm bg-white px-2 py-1 font-thin",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    className: "mr-1 h-5 w-5",
                                                    viewBox: "0 0 20 20",
                                                    fill: "currentColor",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        fillRule: "evenodd",
                                                        d: "M17.707 9.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A.997.997 0 012 10V5a3 3 0 013-3h5c.256 0 .512.098.707.293l7 7zM5 6a1 1 0 100-2 1 1 0 000 2z",
                                                        clipRule: "evenodd"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-sm font-thin",
                                                    children: tour.type.toUpperCase()
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center rounded-sm bg-white px-2 py-1 font-thin",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "16",
                                                    height: "16",
                                                    viewBox: "0 0 16 16",
                                                    className: "mr-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            fill: "#000",
                                                            d: "M6.16 4.6A4.054 4.054 0 0 1 8 7.994v0c0-1.415.726-2.66 1.825-3.384a2.857 2.857 0 0 0 1.17-1.589L5 3.001c.191.67.603 1.225 1.15 1.594z"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            fill: "#000",
                                                            d: "M11.18 6.06A4.399 4.399 0 0 0 13 2.5V2h1V0H2v2h1v.5a4.391 4.391 0 0 0 1.808 3.551A2.564 2.564 0 0 1 6 7.99a2.755 2.755 0 0 1-1.209 2.003 4.441 4.441 0 0 0-1.79 3.503v.503h-1v2h12v-2h-1v-.5a4.435 4.435 0 0 0-1.769-3.492 2.762 2.762 0 0 1-1.23-1.996 2.551 2.551 0 0 1 1.169-1.946zM9 8a3.693 3.693 0 0 0 1.519 2.763A3.477 3.477 0 0 1 12 13.495V14H4v-.5a3.472 3.472 0 0 1 1.459-2.723 3.698 3.698 0 0 0 1.54-2.766 3.482 3.482 0 0 0-1.498-2.683 3.438 3.438 0 0 1-1.502-2.827v-.5h8v.5a3.426 3.426 0 0 1-1.479 2.813 3.487 3.487 0 0 0-1.521 2.678z"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-sm font-thin",
                                                    children: tour.time
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                tour.badge && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "absolute top-6 right-6 rounded bg-[#963f45] py-1 px-4 text-sm font-thin text-white",
                                    children: tour.badge
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: tour.image,
                        layout: "responsive",
                        width: 550,
                        height: 300,
                        className: "relative z-0"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-1 flex-col gap-2 p-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "card-title text-2xl transition duration-300",
                        children: tour.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "sm:text-md flex-1 text-lg font-thin",
                        children: tour.description
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "rounded-sm bg-[#047857] py-3 px-16 text-white transition duration-300 hover:bg-[#064e3b]",
                        children: "LEARN MORE"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_card = (card);

;// CONCATENATED MODULE: ./components/Services.tsx



const Services = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "py-20 px-12",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "bg-gray-100 py-10 px-6 sm:px-10 md:px-32 text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "mb-2 text-3xl",
                            children: "#5 in the World for Cultural Experiences"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-lg font-thin",
                            children: "Great news! In 2019 TripAdvisor Travelers\u2019 Choice Award ranked Edinburgh Guided Tour at number 5 in the world for cultural experiences! An outstanding result for a small business."
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mt-20 flex flex-col md:flex-row gap-10",
                    children: tours.map((tour)=>/*#__PURE__*/ jsx_runtime_.jsx(components_card, {
                            tour: tour
                        }, tour.id)
                    )
                })
            ]
        })
    });
};
/* harmony default export */ const components_Services = (Services);

;// CONCATENATED MODULE: ./components/MyStory.tsx



const MyStory = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col lg:flex-row gap-20 bg-[#394c6f] px-10 py-20",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "basis-1/2 text-white",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-4 text-2xl",
                            children: "My Story"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-col gap-4",
                            children: myStory.map((story)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: `${story.style ? "text-xl" : ""} leading-7`,
                                    children: story.text
                                }, story.id)
                            )
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col sm:flex-row lg:flex-col basis-1/2 gap-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/img/tourist-guide.jpg",
                            width: 500,
                            height: 450
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/img/with-tourists.jpg",
                            width: 500,
                            height: 450
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_MyStory = (MyStory);

;// CONCATENATED MODULE: ./components/WalkingTour.tsx



const WalkingTour = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col items-center md:flex-row-reverse gap-20 px-10 py-20 bg-[#f2f2f3]",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "basis-1/2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-4 text-3xl",
                            children: "The Walking Tour"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-col gap-4",
                            children: walkingTour.map((tour)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "leading-7",
                                    children: tour.text
                                }, tour.id)
                            )
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-col sm:flex-row lg:flex-col basis-1/2 gap-4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/img/walking-tour.jpg",
                        width: 500,
                        height: 450
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_WalkingTour = (WalkingTour);

// EXTERNAL MODULE: ./components/Footer.tsx
var Footer = __webpack_require__(260);
;// CONCATENATED MODULE: ./pages/index.tsx







const Home = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Hero/* default */.Z, {
                position: "center",
                title: "Tangier Guided Tour",
                text: true,
                image: "/img/tangier-hero.jpg"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Services, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_MyStory, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_WalkingTour, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
};
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,61,355], () => (__webpack_exec__(690)));
module.exports = __webpack_exports__;

})();