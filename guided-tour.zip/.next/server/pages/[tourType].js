"use strict";
(() => {
var exports = {};
exports.id = 271;
exports.ids = [271];
exports.modules = {

/***/ 972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _tourType_),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/Navbar.tsx
var Navbar = __webpack_require__(951);
// EXTERNAL MODULE: ./components/Hero.tsx
var Hero = __webpack_require__(547);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/DetailsCard.tsx


const DetailsCard = ({ pricesDetails  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "sticky top-4 mt-8 sm:mt-0 card basis-2/5 w-full overflow-hidden rounded-t-xl shadow-xl",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative md:w-[350px] h-[400px] cursor-pointer",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: pricesDetails.image,
                    layout: "fill",
                    objectFit: "cover",
                    objectPosition: "center-center"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-1 flex-col gap-2 p-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "card-title text-2xl transition duration-300"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "sm:text-md flex-1 text-lg font-thin"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "rounded-sm bg-[#047857] py-3 px-16 text-white transition duration-300 hover:bg-[#064e3b]",
                        children: "BOOK MY TOUR"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        children: pricesDetails.prices.map((price, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "flex justify-between text-gray-900 py-2 border-t-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: price.category
                                    }),
                                    "  ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-lg font-medium",
                                        children: price.price
                                    })
                                ]
                            }, i)
                        )
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_DetailsCard = (DetailsCard);

;// CONCATENATED MODULE: ./components/TourDetails.tsx


const TourDetails = ({ tourDets , tour  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "md:flex justify-between py-20 px-10",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "basis-3/5 mb-6 sm:mr-3",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-4 bg-gray-100 p-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                    children: "QUICK DETAILS"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex sm:items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "mr-1 mt-1 sm:mt-0 h-5 w-5",
                                            viewBox: "0 0 20 20",
                                            fill: "currentColor",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                fillRule: "evenodd",
                                                d: "M17.707 9.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A.997.997 0 012 10V5a3 3 0 013-3h5c.256 0 .512.098.707.293l7 7zM5 6a1 1 0 100-2 1 1 0 000 2z",
                                                clipRule: "evenodd"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Category: "
                                                }),
                                                tour.type
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "16",
                                            height: "16",
                                            viewBox: "0 0 16 16",
                                            className: "mr-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fill: "#000",
                                                    d: "M6.16 4.6A4.054 4.054 0 0 1 8 7.994v0c0-1.415.726-2.66 1.825-3.384a2.857 2.857 0 0 0 1.17-1.589L5 3.001c.191.67.603 1.225 1.15 1.594z"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fill: "#000",
                                                    d: "M11.18 6.06A4.399 4.399 0 0 0 13 2.5V2h1V0H2v2h1v.5a4.391 4.391 0 0 0 1.808 3.551A2.564 2.564 0 0 1 6 7.99a2.755 2.755 0 0 1-1.209 2.003 4.441 4.441 0 0 0-1.79 3.503v.503h-1v2h12v-2h-1v-.5a4.435 4.435 0 0 0-1.769-3.492 2.762 2.762 0 0 1-1.23-1.996 2.551 2.551 0 0 1 1.169-1.946zM9 8a3.693 3.693 0 0 0 1.519 2.763A3.477 3.477 0 0 1 12 13.495V14H4v-.5a3.472 3.472 0 0 1 1.459-2.723 3.698 3.698 0 0 0 1.54-2.766 3.482 3.482 0 0 0-1.498-2.683 3.438 3.438 0 0 1-1.502-2.827v-.5h8v.5a3.426 3.426 0 0 1-1.479 2.813 3.487 3.487 0 0 0-1.521 2.678z"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Duration: "
                                                }),
                                                tour.time
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: tourDets.description
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "list-disc pl-4",
                                    children: tourDets.infoList && tourDets.infoList.map((info)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                                    children: [
                                                        info.name,
                                                        ": "
                                                    ]
                                                }),
                                                info.value
                                            ]
                                        }, info.name)
                                    )
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-4 space-y-4 text-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: tourDets.text
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "text-3xl",
                                    children: tourDets.title1
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "list-disc pl-4",
                                    children: tourDets.tourList2.map((trList)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: trList
                                        }, trList)
                                    )
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-3xl",
                                    children: tourDets.title2
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "space-y-4",
                                    children: tourDets.paragraphs.map((para, i)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: para
                                        }, i)
                                    )
                                }),
                                tourDets.title3 && /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-3xl",
                                    children: tourDets.title3
                                }),
                                tourDets.paragraphs2.length != 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "space-y-4",
                                    children: tourDets.paragraphs.map((para, i)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: para
                                        }, i)
                                    )
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_DetailsCard, {
                        pricesDetails: tourDets.pricesDetails
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_TourDetails = (TourDetails);

// EXTERNAL MODULE: ./components/Footer.tsx
var Footer = __webpack_require__(260);
;// CONCATENATED MODULE: ./pages/[tourType]/index.tsx





const Tours = ({ tourDets , tour  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Hero/* default */.Z, {
                position: "left",
                title: tour.title,
                image: tour.image
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_TourDetails, {
                tourDets: tourDets,
                tour: tour
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
};
/* harmony default export */ const _tourType_ = (Tours);
async function getStaticPaths() {
    const res = await fetch(`${process.env.BASE_URL}/api/getData`);
    const { tours  } = await res.json();
    const paths = tours.map((tr)=>{
        return {
            params: {
                tourType: `${tr.id}`
            }
        };
    });
    return {
        paths,
        fallback: false
    };
}
async function getStaticProps({ params: { tourType  }  }) {
    const res = await fetch(`${process.env.BASE_URL}/api/getData`);
    const { toursDets , tours  } = await res.json();
    const tourDets = toursDets.filter((trDets)=>trDets.id === tourType
    )[0];
    const tour = tours.filter((tr)=>tr.id === tourType
    )[0];
    console.log("tourDets", tourDets);
    console.log("tour", tour);
    return {
        props: {
            tourDets,
            tour
        }
    };
}


/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,61,355], () => (__webpack_exec__(972)));
module.exports = __webpack_exports__;

})();